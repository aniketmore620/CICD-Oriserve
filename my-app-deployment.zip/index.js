const express = require('express');
const app = express();

app.get('/', (req, res) => {
    res.send('Welocome To CICD Pipeline!');
});

const port = 3000;
app.listen(port, () => {
    console.log(`App running on port ${port}`);
});

