#!/bin/bash
cd /home/ubuntu/my-app
npm install

